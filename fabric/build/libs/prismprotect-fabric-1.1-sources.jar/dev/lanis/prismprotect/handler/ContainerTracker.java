package dev.lanis.prismprotect.handler;

import dev.lanis.prismprotect.PrismProtect;
import dev.lanis.prismprotect.database.ContainerLogEntry;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_7923;

public final class ContainerTracker {

    private static final Map<UUID, BlockInfo> LAST_INTERACTED_BLOCK = new ConcurrentHashMap<>();
    private static final Map<UUID, Snapshot> SNAPSHOTS = new ConcurrentHashMap<>();

    private ContainerTracker() {
    }

    record BlockInfo(class_2338 pos, String world) {
    }

    record Snapshot(class_2338 pos, String world, Map<String, SlotCount> counts) {
    }

    record SlotCount(String itemType, String itemData, int count) {
    }

    public static void storeInteract(UUID playerId, class_2338 pos, String world) {
        LAST_INTERACTED_BLOCK.put(playerId, new BlockInfo(pos, world));
    }

    public static void onOpen(UUID playerId, class_1703 menu) {
        BlockInfo blockInfo = LAST_INTERACTED_BLOCK.get(playerId);
        if (blockInfo == null) {
            return;
        }

        SNAPSHOTS.put(playerId, new Snapshot(blockInfo.pos, blockInfo.world, aggregate(menu)));
    }

    public static void onClose(UUID playerId, class_1703 menu, String playerName) {
        Snapshot snapshot = SNAPSHOTS.remove(playerId);
        if (snapshot == null) {
            return;
        }

        Map<String, SlotCount> before = snapshot.counts;
        Map<String, SlotCount> after = aggregate(menu);
        long eventTime = System.currentTimeMillis();

        for (Map.Entry<String, SlotCount> entry : before.entrySet()) {
            SlotCount beforeCount = entry.getValue();
            int previous = beforeCount.count;
            int current = after.getOrDefault(entry.getKey(), new SlotCount(beforeCount.itemType, beforeCount.itemData, 0)).count;

            int diff = previous - current;
            if (diff > 0) {
                PrismProtect.getDatabase().logContainer(new ContainerLogEntry(
                        eventTime,
                        playerName,
                        snapshot.world,
                        snapshot.pos.method_10263(),
                        snapshot.pos.method_10264(),
                        snapshot.pos.method_10260(),
                        beforeCount.itemType,
                        diff,
                        beforeCount.itemData,
                        ContainerLogEntry.ACTION_REMOVE
                ));
            }
        }

        for (Map.Entry<String, SlotCount> entry : after.entrySet()) {
            SlotCount afterCount = entry.getValue();
            int current = afterCount.count;
            int previous = before.getOrDefault(entry.getKey(), new SlotCount(afterCount.itemType, afterCount.itemData, 0)).count;

            int diff = current - previous;
            if (diff > 0) {
                PrismProtect.getDatabase().logContainer(new ContainerLogEntry(
                        eventTime,
                        playerName,
                        snapshot.world,
                        snapshot.pos.method_10263(),
                        snapshot.pos.method_10264(),
                        snapshot.pos.method_10260(),
                        afterCount.itemType,
                        diff,
                        afterCount.itemData,
                        ContainerLogEntry.ACTION_ADD
                ));
            }
        }
    }

    public static void clear(UUID playerId) {
        LAST_INTERACTED_BLOCK.remove(playerId);
        SNAPSHOTS.remove(playerId);
    }

    private static Map<String, SlotCount> aggregate(class_1703 menu) {
        Map<String, SlotCount> counts = new LinkedHashMap<>();

        for (class_1735 slot : menu.field_7761) {
            if (slot.field_7871 instanceof class_1661) {
                continue;
            }

            class_1799 stack = slot.method_7677();
            if (stack.method_7960()) {
                continue;
            }

            String key = itemKey(stack);
            String itemType = class_7923.field_41178.method_10221(stack.method_7909()).toString();
            String itemData = nbtWithoutCount(stack);

            counts.merge(
                    key,
                    new SlotCount(itemType, itemData, stack.method_7947()),
                    (previous, next) -> new SlotCount(previous.itemType, previous.itemData, previous.count + next.count)
            );
        }

        return counts;
    }

    private static String itemKey(class_1799 stack) {
        String type = class_7923.field_41178.method_10221(stack.method_7909()).toString();
        class_2487 tag = stack.method_7969();
        return type + (tag != null ? "|" + tag : "");
    }

    private static String nbtWithoutCount(class_1799 stack) {
        if (!stack.method_7985()) {
            return null;
        }

        class_2487 copy = stack.method_7969().method_10553();
        copy.method_10551("Count");
        return copy.method_33133() ? null : copy.toString();
    }
}
