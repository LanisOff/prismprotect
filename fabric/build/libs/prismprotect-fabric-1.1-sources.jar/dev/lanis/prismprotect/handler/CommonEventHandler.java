package dev.lanis.prismprotect.handler;

import dev.architectury.event.EventResult;
import dev.architectury.event.events.common.BlockEvent;
import dev.architectury.event.events.common.EntityEvent;
import dev.architectury.event.events.common.ExplosionEvent;
import dev.architectury.event.events.common.InteractionEvent;
import dev.architectury.event.events.common.PlayerEvent;
import dev.architectury.utils.value.IntValue;
import dev.lanis.prismprotect.PrismProtect;
import dev.lanis.prismprotect.database.BlockLogEntry;
import dev.lanis.prismprotect.database.EntityLogEntry;
import dev.lanis.prismprotect.database.LookupParams;
import dev.lanis.prismprotect.util.MessageUtil;
import dev.lanis.prismprotect.util.TimeUtil;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.class_1268;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7923;

public final class CommonEventHandler {

    private static final AtomicBoolean REGISTERED = new AtomicBoolean(false);

    private CommonEventHandler() {
    }

    public static void register() {
        if (!REGISTERED.compareAndSet(false, true)) {
            return;
        }

        BlockEvent.BREAK.register(CommonEventHandler::onBreak);
        BlockEvent.PLACE.register(CommonEventHandler::onPlace);
        ExplosionEvent.DETONATE.register(CommonEventHandler::onExplosion);
        EntityEvent.LIVING_DEATH.register(CommonEventHandler::onEntityDeath);
        InteractionEvent.RIGHT_CLICK_BLOCK.register(CommonEventHandler::onRightClickBlock);
        PlayerEvent.OPEN_MENU.register(CommonEventHandler::onContainerOpen);
        PlayerEvent.CLOSE_MENU.register(CommonEventHandler::onContainerClose);
        PlayerEvent.PLAYER_QUIT.register(CommonEventHandler::onPlayerLogout);
    }

    private static EventResult onBreak(
            class_1937 level,
            class_2338 pos,
            class_2680 state,
            class_3222 player,
            IntValue xp
    ) {
        if (!(level instanceof class_3218 serverLevel)) {
            return EventResult.pass();
        }

        if (InspectManager.isInspecting(player.method_5667())) {
            showInspect(player, serverLevel, pos, blockId(state));
            return EventResult.interruptFalse();
        }

        PrismProtect.getDatabase().logBlock(new BlockLogEntry(
                now(),
                player.method_7334().getName(),
                worldName(serverLevel),
                pos.method_10263(),
                pos.method_10264(),
                pos.method_10260(),
                blockId(state),
                beData(serverLevel, pos),
                BlockLogEntry.ACTION_BREAK
        ));

        return EventResult.pass();
    }

    private static EventResult onPlace(class_1937 level, class_2338 pos, class_2680 state, class_1297 placer) {
        if (!(level instanceof class_3218 serverLevel) || !(placer instanceof class_3222 player)) {
            return EventResult.pass();
        }

        PrismProtect.getDatabase().logBlock(new BlockLogEntry(
                now(),
                player.method_7334().getName(),
                worldName(serverLevel),
                pos.method_10263(),
                pos.method_10264(),
                pos.method_10260(),
                blockId(state),
                null,
                BlockLogEntry.ACTION_PLACE
        ));

        return EventResult.pass();
    }

    private static void onExplosion(class_1937 level, class_1927 explosion, List<class_1297> affectedEntities) {
        if (!(level instanceof class_3218 serverLevel)) {
            return;
        }

        String world = worldName(serverLevel);
        String source = resolveExplosionSource(explosion);
        long eventTime = now();

        for (class_2338 pos : explosion.method_8346()) {
            class_2680 state = serverLevel.method_8320(pos);
            if (state.method_26215()) {
                continue;
            }

            PrismProtect.getDatabase().logBlock(new BlockLogEntry(
                    eventTime,
                    source,
                    world,
                    pos.method_10263(),
                    pos.method_10264(),
                    pos.method_10260(),
                    blockId(state),
                    beData(serverLevel, pos),
                    BlockLogEntry.ACTION_EXPLODE
            ));
        }

        BlockChangeContext.EXPLOSION_HANDLED.set(true);
    }

    private static EventResult onEntityDeath(class_1309 target, class_1282 source) {
        if (target instanceof class_1657 || !(target.method_37908() instanceof class_3218 serverLevel)) {
            return EventResult.pass();
        }

        class_3222 killer = source.method_5529() instanceof class_3222 serverPlayer ? serverPlayer : null;

        String entityType = class_7923.field_41177.method_10221(target.method_5864()).toString();
        class_2487 serialized = new class_2487();
        target.method_5662(serialized);

        PrismProtect.getDatabase().logEntity(new EntityLogEntry(
                now(),
                killer != null ? killer.method_7334().getName() : "#environment",
                worldName(serverLevel),
                target.method_23317(),
                target.method_23318(),
                target.method_23321(),
                entityType,
                serialized.toString(),
                EntityLogEntry.ACTION_KILL
        ));

        return EventResult.pass();
    }

    private static EventResult onRightClickBlock(class_1657 player, class_1268 hand, class_2338 pos, class_2350 face) {
        if (!(player instanceof class_3222 serverPlayer) || !(player.method_37908() instanceof class_3218 serverLevel)) {
            return EventResult.pass();
        }

        ContainerTracker.storeInteract(serverPlayer.method_5667(), pos, worldName(serverLevel));

        if (InspectManager.isInspecting(serverPlayer.method_5667())) {
            class_2680 state = serverLevel.method_8320(pos);
            showInspect(serverPlayer, serverLevel, pos, blockId(state));
            return EventResult.interruptFalse();
        }

        return EventResult.pass();
    }

    private static void onContainerOpen(class_1657 player, class_1703 menu) {
        if (player instanceof class_3222 serverPlayer) {
            ContainerTracker.onOpen(serverPlayer.method_5667(), menu);
        }
    }

    private static void onContainerClose(class_1657 player, class_1703 menu) {
        if (player instanceof class_3222 serverPlayer) {
            ContainerTracker.onClose(serverPlayer.method_5667(), menu, serverPlayer.method_7334().getName());
        }
    }

    private static void onPlayerLogout(class_3222 player) {
        ContainerTracker.clear(player.method_5667());
    }

    private static void showInspect(class_3222 player, class_1937 level, class_2338 pos, String blockType) {
        LookupParams params = new LookupParams();
        params.world = worldName(level);
        params.minX = pos.method_10263();
        params.maxX = pos.method_10263();
        params.minY = pos.method_10264();
        params.maxY = pos.method_10264();
        params.minZ = pos.method_10260();
        params.maxZ = pos.method_10260();
        params.limit = 10;

        List<BlockLogEntry> entries = PrismProtect.getDatabase().lookupBlocks(params);

        player.method_43496(MessageUtil.header("Block Info"));
        player.method_43496(class_2561.method_43470(
                "§7Block: §e" + blockType + " §7(" + pos.method_10263() + "," + pos.method_10264() + "," + pos.method_10260() + ")"
        ));

        if (entries.isEmpty()) {
            player.method_43496(MessageUtil.warn("No history found for this block."));
            return;
        }

        for (BlockLogEntry entry : entries) {
            player.method_43496(class_2561.method_43470(String.format(
                    "§7%s §f%s §7%s §e%s%s",
                    TimeUtil.elapsed(entry.time),
                    entry.player,
                    entry.actionName(),
                    entry.blockType,
                    entry.rolledBack ? " §8[rb]" : ""
            )));
        }
    }

    public static String blockId(class_2680 state) {
        return class_7923.field_41175.method_10221(state.method_26204()).toString();
    }

    private static String resolveExplosionSource(class_1927 explosion) {
        class_1282 damageSource = explosion.method_8349();
        if (damageSource == null) {
            return "#explosion";
        }

        class_1297 indirect = damageSource.method_5529();
        if (indirect instanceof class_3222 player) {
            return player.method_7334().getName();
        }

        class_1297 direct = damageSource.method_5526();
        if (direct != null) {
            return "#" + class_7923.field_41177.method_10221(direct.method_5864()).method_12832();
        }

        return "#explosion";
    }

    private static String worldName(class_1937 level) {
        return level.method_27983().method_29177().toString();
    }

    private static String beData(class_1937 level, class_2338 pos) {
        class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity == null) {
            return null;
        }

        class_2487 tag = blockEntity.method_38244();
        return tag.method_33133() ? null : tag.toString();
    }

    private static long now() {
        return System.currentTimeMillis();
    }
}
