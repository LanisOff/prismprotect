package dev.lanis.prismprotect.util;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public final class MessageUtil {

    private static final String PRE = "§8[§b✦ PP§8] §r";

    private MessageUtil() {}

    public static class_2561 raw(String text)     { return class_2561.method_43470(PRE + text); }
    public static class_2561 success(String text) { return col(text, class_124.field_1060); }
    public static class_2561 error(String text)   { return col(text, class_124.field_1061); }
    public static class_2561 warn(String text)    { return col(text, class_124.field_1054); }
    public static class_2561 info(String text)    { return col(text, class_124.field_1075); }

    public static class_2561 header(String title) {
        return class_2561.method_43470("§8§m───────§r §b✦ §f" + title + " §b✦§r §8§m───────");
    }

    public static class_2561 divider() {
        return class_2561.method_43470("§8§m───────────────────────────§r");
    }

    private static class_2561 col(String t, class_124 f) {
        class_5250 c = class_2561.method_43470(PRE);
        c.method_10852(class_2561.method_43470(t).method_27692(f));
        return c;
    }
}
