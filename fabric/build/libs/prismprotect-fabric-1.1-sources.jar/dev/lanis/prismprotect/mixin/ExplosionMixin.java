package dev.lanis.prismprotect.mixin;

import dev.lanis.prismprotect.PrismProtect;
import dev.lanis.prismprotect.database.BlockLogEntry;
import dev.lanis.prismprotect.handler.BlockChangeContext;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1927.class)
public abstract class ExplosionMixin {

    @Final @Shadow private class_1937 level;

    @Inject(method = "finalizeExplosion", at = @At("HEAD"))
    private void prismprotect$maybeLogExplosion(boolean causeFire, CallbackInfo ci) {
        if (BlockChangeContext.EXPLOSION_HANDLED.get()) return;
        if (!(level instanceof class_3218 sl)) return;

        class_1927 explosion = (class_1927) (Object) this;
        String source = resolveSource(explosion.method_8349());
        String world = sl.method_27983().method_29177().toString();
        long now = System.currentTimeMillis();

        for (class_2338 pos : explosion.method_8346()) {
            class_2680 state = sl.method_8320(pos);
            if (state.method_26215()) continue;

            String beData = null;
            class_2586 be = sl.method_8321(pos);
            if (be != null) {
                class_2487 tag = be.method_38244();
                if (!tag.method_33133()) beData = tag.toString();
            }

            PrismProtect.getDatabase().logBlock(new BlockLogEntry(
                    now, source, world,
                    pos.method_10263(), pos.method_10264(), pos.method_10260(),
                    class_7923.field_41175.method_10221(state.method_26204()).toString(),
                    beData, BlockLogEntry.ACTION_EXPLODE
            ));
        }
    }

    @Inject(method = "finalizeExplosion", at = @At("RETURN"))
    private void prismprotect$clearFlag(boolean causeFire, CallbackInfo ci) {
        BlockChangeContext.EXPLOSION_HANDLED.set(false);
    }

    private static String resolveSource(class_1282 ds) {
        class_1297 indirect = ds.method_5529();
        if (indirect instanceof class_3222 sp)
            return sp.method_7334().getName();
        class_1297 direct = ds.method_5526();
        if (direct != null)
            return "#" + class_7923.field_41177.method_10221(direct.method_5864()).method_12832();
        return "#explosion";
    }
}
