package dev.lanis.prismprotect.mixin;

import dev.lanis.prismprotect.PrismProtect;
import dev.lanis.prismprotect.database.BlockLogEntry;
import dev.lanis.prismprotect.handler.BlockChangeContext;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4770;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1937.class)
public abstract class LevelSetBlockMixin {

    @Inject(
        method = "setBlock(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;I)Z",
        at = @At("HEAD")
    )
    private void prismprotect$onSetBlock(
            class_2338 pos, class_2680 newState, int flags,
            CallbackInfoReturnable<Boolean> cir) {

        if (BlockChangeContext.IN_FIRE_TICK.get() && (Object) this instanceof class_3218 sl) {
            class_2680 oldState = sl.method_8320(pos);
            if (!oldState.method_26215() && newState.method_26204() instanceof class_4770) {
                PrismProtect.getDatabase().logBlock(new BlockLogEntry(
                        System.currentTimeMillis(),
                        "#fire",
                        sl.method_27983().method_29177().toString(),
                        pos.method_10263(), pos.method_10264(), pos.method_10260(),
                        class_7923.field_41175.method_10221(oldState.method_26204()).toString(),
                        null,
                        BlockLogEntry.ACTION_BREAK
                ));
            }
        }
    }
}
