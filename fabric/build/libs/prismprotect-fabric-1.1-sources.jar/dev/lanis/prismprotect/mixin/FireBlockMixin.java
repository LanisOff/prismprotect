package dev.lanis.prismprotect.mixin;

import dev.lanis.prismprotect.handler.BlockChangeContext;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(net.minecraft.class_2358.class)
public abstract class FireBlockMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void prismprotect$enterFireTick(
            class_2680 state, class_3218 level, class_2338 pos, class_5819 random, CallbackInfo ci) {
        BlockChangeContext.IN_FIRE_TICK.set(true);
    }

    @Inject(method = "tick", at = @At("RETURN"))
    private void prismprotect$exitFireTick(
            class_2680 state, class_3218 level, class_2338 pos, class_5819 random, CallbackInfo ci) {
        BlockChangeContext.IN_FIRE_TICK.set(false);
    }
}
