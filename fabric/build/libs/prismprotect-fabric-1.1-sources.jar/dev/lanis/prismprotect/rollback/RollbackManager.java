package dev.lanis.prismprotect.rollback;

import dev.lanis.prismprotect.PrismProtect;
import dev.lanis.prismprotect.database.BlockLogEntry;
import dev.lanis.prismprotect.database.ContainerLogEntry;
import dev.lanis.prismprotect.database.EntityLogEntry;
import dev.lanis.prismprotect.database.LookupParams;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2522;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import java.util.List;
import java.util.Optional;

public final class RollbackManager {

    private RollbackManager() {
    }

    public static int rollback(MinecraftServer server, LookupParams params) {
        List<BlockLogEntry> entries = PrismProtect.getDatabase().getForRollback(params);
        int restoredCount = 0;

        for (BlockLogEntry entry : entries) {
            class_3218 level = findLevel(server, entry.world);
            if (level == null) {
                continue;
            }

            class_2338 pos = new class_2338(entry.x, entry.y, entry.z);
            try {
                if (entry.action == BlockLogEntry.ACTION_PLACE) {
                    level.method_8652(pos, class_2246.field_10124.method_9564(), class_2248.field_31036);
                    PrismProtect.getDatabase().setBlockRolledBack(entry.id, true);
                    restoredCount++;
                    continue;
                }

                if (entry.action == BlockLogEntry.ACTION_BREAK
                        || entry.action == BlockLogEntry.ACTION_EXPLODE
                        || entry.action == BlockLogEntry.ACTION_BURN) {
                    class_2680 state = resolveState(entry.blockType);
                    if (state != null) {
                        level.method_8652(pos, state, class_2248.field_31036);
                        if (entry.blockData != null) {
                            restoreBlockEntity(level, pos, entry.blockData);
                        }
                        PrismProtect.getDatabase().setBlockRolledBack(entry.id, true);
                        restoredCount++;
                    }
                }
            } catch (Exception ex) {
                PrismProtect.LOGGER.warn("Rollback error at {}: {}", pos, ex.getMessage());
            }
        }

        return restoredCount;
    }

    public static int restore(MinecraftServer server, LookupParams params) {
        List<BlockLogEntry> entries = PrismProtect.getDatabase().getForRestore(params);
        int restoredCount = 0;

        for (BlockLogEntry entry : entries) {
            class_3218 level = findLevel(server, entry.world);
            if (level == null) {
                continue;
            }

            class_2338 pos = new class_2338(entry.x, entry.y, entry.z);
            try {
                if (entry.action == BlockLogEntry.ACTION_PLACE) {
                    class_2680 state = resolveState(entry.blockType);
                    if (state != null) {
                        level.method_8652(pos, state, class_2248.field_31036);
                        PrismProtect.getDatabase().setBlockRolledBack(entry.id, false);
                        restoredCount++;
                    }
                    continue;
                }

                if (entry.action == BlockLogEntry.ACTION_BREAK
                        || entry.action == BlockLogEntry.ACTION_EXPLODE
                        || entry.action == BlockLogEntry.ACTION_BURN) {
                    level.method_8652(pos, class_2246.field_10124.method_9564(), class_2248.field_31036);
                    PrismProtect.getDatabase().setBlockRolledBack(entry.id, false);
                    restoredCount++;
                }
            } catch (Exception ex) {
                PrismProtect.LOGGER.warn("Restore error at {}: {}", pos, ex.getMessage());
            }
        }

        return restoredCount;
    }

    public static int rollbackEntities(MinecraftServer server, LookupParams params) {
        List<EntityLogEntry> entries = PrismProtect.getDatabase().getEntitiesForRollback(params);
        int restoredCount = 0;

        for (EntityLogEntry entry : entries) {
            if (entry.action != EntityLogEntry.ACTION_KILL) {
                continue;
            }

            class_3218 level = findLevel(server, entry.world);
            if (level == null) {
                continue;
            }

            try {
                class_2960 entityId = new class_2960(entry.entityType);
                Optional<class_1299<?>> type = class_7923.field_41177.method_17966(entityId);
                if (type.isEmpty()) {
                    continue;
                }

                class_1297 entity = type.get().method_5883(level);
                if (entity == null) {
                    continue;
                }

                entity.method_5814(entry.x, entry.y, entry.z);

                if (entry.entityData != null && !entry.entityData.isBlank()) {
                    try {
                        class_2487 tag = class_2522.method_10718(entry.entityData);
                        entity.method_5651(tag);
                        entity.method_5814(entry.x, entry.y, entry.z);
                    } catch (Exception nbtEx) {
                        PrismProtect.LOGGER.warn("Entity NBT restore failed: {}", nbtEx.getMessage());
                    }
                }

                level.method_8649(entity);
                PrismProtect.getDatabase().setEntityRolledBack(entry.id, true);
                restoredCount++;
            } catch (Exception ex) {
                PrismProtect.LOGGER.warn("Entity rollback error: {}", ex.getMessage());
            }
        }

        return restoredCount;
    }

    public static int rollbackContainers(MinecraftServer server, LookupParams params) {
        List<ContainerLogEntry> entries = PrismProtect.getDatabase().getContainerForRollback(params);
        int restoredCount = 0;

        for (ContainerLogEntry entry : entries) {
            class_3218 level = findLevel(server, entry.world);
            if (level == null) {
                continue;
            }

            class_2338 pos = new class_2338(entry.x, entry.y, entry.z);
            class_1799 stack = buildStack(entry);
            if (stack.method_7960()) {
                continue;
            }

            try {
                if (entry.action == ContainerLogEntry.ACTION_REMOVE) {
                    if (PrismProtect.getContainerAccess().addItem(level, pos, stack)) {
                        PrismProtect.getDatabase().setContainerRolledBack(entry.id, true);
                        restoredCount++;
                    }
                    continue;
                }

                if (entry.action == ContainerLogEntry.ACTION_ADD) {
                    if (PrismProtect.getContainerAccess().removeItem(level, pos, stack)) {
                        PrismProtect.getDatabase().setContainerRolledBack(entry.id, true);
                        restoredCount++;
                    }
                }
            } catch (Exception ex) {
                PrismProtect.LOGGER.warn("Container rollback error at {}: {}", pos, ex.getMessage());
            }
        }

        return restoredCount;
    }

    public static int restoreContainers(MinecraftServer server, LookupParams params) {
        List<ContainerLogEntry> entries = PrismProtect.getDatabase().getContainerForRestore(params);
        int restoredCount = 0;

        for (ContainerLogEntry entry : entries) {
            class_3218 level = findLevel(server, entry.world);
            if (level == null) {
                continue;
            }

            class_2338 pos = new class_2338(entry.x, entry.y, entry.z);
            class_1799 stack = buildStack(entry);
            if (stack.method_7960()) {
                continue;
            }

            try {
                if (entry.action == ContainerLogEntry.ACTION_REMOVE) {
                    if (PrismProtect.getContainerAccess().removeItem(level, pos, stack)) {
                        PrismProtect.getDatabase().setContainerRolledBack(entry.id, false);
                        restoredCount++;
                    }
                    continue;
                }

                if (entry.action == ContainerLogEntry.ACTION_ADD) {
                    if (PrismProtect.getContainerAccess().addItem(level, pos, stack)) {
                        PrismProtect.getDatabase().setContainerRolledBack(entry.id, false);
                        restoredCount++;
                    }
                }
            } catch (Exception ex) {
                PrismProtect.LOGGER.warn("Container restore error at {}: {}", pos, ex.getMessage());
            }
        }

        return restoredCount;
    }

    private static class_1799 buildStack(ContainerLogEntry entry) {
        try {
            class_1792 item = class_7923.field_41178.method_10223(new class_2960(entry.itemType));
            if (item == class_1802.field_8162) {
                return class_1799.field_8037;
            }

            class_1799 stack = new class_1799(item, entry.amount);
            if (entry.itemData != null && !entry.itemData.isBlank()) {
                stack.method_7980(class_2522.method_10718(entry.itemData));
            }
            return stack;
        } catch (Exception ex) {
            PrismProtect.LOGGER.warn("Failed to build ItemStack for {}: {}", entry.itemType, ex.getMessage());
            return class_1799.field_8037;
        }
    }

    private static class_2680 resolveState(String id) {
        try {
            return class_7923.field_41175.method_10223(new class_2960(id)).method_9564();
        } catch (Exception ex) {
            PrismProtect.LOGGER.warn("Unknown block: {}", id);
            return null;
        }
    }

    private static void restoreBlockEntity(class_3218 level, class_2338 pos, String nbt) {
        try {
            class_2586 blockEntity = level.method_8321(pos);
            if (blockEntity != null && nbt.startsWith("{")) {
                blockEntity.method_11014(class_2522.method_10718(nbt));
                blockEntity.method_5431();
            }
        } catch (Exception ex) {
            PrismProtect.LOGGER.warn("BlockEntity restore failed at {}: {}", pos, ex.getMessage());
        }
    }

    private static class_3218 findLevel(MinecraftServer server, String worldName) {
        for (class_3218 level : server.method_3738()) {
            String location = level.method_27983().method_29177().toString();
            if (location.equals(worldName) || location.replace("minecraft:", "").equals(worldName)) {
                return level;
            }
        }
        return null;
    }
}
