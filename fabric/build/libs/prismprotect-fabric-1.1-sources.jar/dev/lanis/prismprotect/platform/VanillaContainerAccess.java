package dev.lanis.prismprotect.platform;

import dev.lanis.prismprotect.PrismProtect;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_3218;

public class VanillaContainerAccess implements ContainerAccess {

    @Override
    public boolean addItem(class_3218 level, class_2338 pos, class_1799 stack) {
        class_2586 be = level.method_8321(pos);
        if (!(be instanceof class_1263 container)) {
            PrismProtect.LOGGER.warn("Block at {} has no vanilla inventory", pos);
            return false;
        }

        class_1799 remaining = stack.method_7972();
        for (int slot = 0; slot < container.method_5439() && !remaining.method_7960(); slot++) {
            class_1799 existing = container.method_5438(slot);
            if (existing.method_7960()) {
                container.method_5447(slot, remaining.method_7971(remaining.method_7947()));
            } else if (class_1799.method_31577(existing, remaining)) {
                int space = Math.min(remaining.method_7947(), existing.method_7914() - existing.method_7947());
                if (space > 0) {
                    existing.method_7933(space);
                    remaining.method_7934(space);
                }
            }
        }

        be.method_5431();
        return true;
    }

    @Override
    public boolean removeItem(class_3218 level, class_2338 pos, class_1799 stack) {
        class_2586 be = level.method_8321(pos);
        if (!(be instanceof class_1263 container)) {
            PrismProtect.LOGGER.warn("Block at {} has no vanilla inventory", pos);
            return false;
        }

        int toRemove = stack.method_7947();
        for (int slot = 0; slot < container.method_5439() && toRemove > 0; slot++) {
            class_1799 slotStack = container.method_5438(slot);
            if (!slotStack.method_7960() && class_1799.method_31577(slotStack, stack)) {
                int take = Math.min(slotStack.method_7947(), toRemove);
                slotStack.method_7934(take);
                if (slotStack.method_7960()) {
                    container.method_5447(slot, class_1799.field_8037);
                }
                toRemove -= take;
            }
        }

        be.method_5431();
        return true;
    }
}
