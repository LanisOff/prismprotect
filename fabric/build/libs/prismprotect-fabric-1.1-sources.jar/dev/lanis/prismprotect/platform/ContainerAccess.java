package dev.lanis.prismprotect.platform;

import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public interface ContainerAccess {

    boolean addItem(class_3218 level, class_2338 pos, class_1799 stack);

    boolean removeItem(class_3218 level, class_2338 pos, class_1799 stack);
}
