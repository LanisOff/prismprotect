package dev.lanis.prismprotect.rollback;

import dev.lanis.prismprotect.PrismProtect;
import dev.lanis.prismprotect.database.BlockLogEntry;
import dev.lanis.prismprotect.database.ContainerLogEntry;
import dev.lanis.prismprotect.database.EntityLogEntry;
import dev.lanis.prismprotect.database.LookupParams;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.TagParser;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;
import java.util.Optional;

public final class RollbackManager {

    private RollbackManager() {
    }

    public static int rollback(MinecraftServer server, LookupParams params) {
        List<BlockLogEntry> entries = PrismProtect.getDatabase().getForRollback(params);
        int restoredCount = 0;

        for (BlockLogEntry entry : entries) {
            ServerLevel level = findLevel(server, entry.world);
            if (level == null) {
                continue;
            }

            BlockPos pos = new BlockPos(entry.x, entry.y, entry.z);
            try {
                if (entry.action == BlockLogEntry.ACTION_PLACE) {
                    level.m_7731_(pos, Blocks.f_50016_.m_49966_(), Block.f_152402_);
                    PrismProtect.getDatabase().setBlockRolledBack(entry.id, true);
                    restoredCount++;
                    continue;
                }

                if (entry.action == BlockLogEntry.ACTION_BREAK
                        || entry.action == BlockLogEntry.ACTION_EXPLODE
                        || entry.action == BlockLogEntry.ACTION_BURN) {
                    BlockState state = resolveState(entry.blockType);
                    if (state != null) {
                        level.m_7731_(pos, state, Block.f_152402_);
                        if (entry.blockData != null) {
                            restoreBlockEntity(level, pos, entry.blockData);
                        }
                        PrismProtect.getDatabase().setBlockRolledBack(entry.id, true);
                        restoredCount++;
                    }
                }
            } catch (Exception ex) {
                PrismProtect.LOGGER.warn("Rollback error at {}: {}", pos, ex.getMessage());
            }
        }

        return restoredCount;
    }

    public static int restore(MinecraftServer server, LookupParams params) {
        List<BlockLogEntry> entries = PrismProtect.getDatabase().getForRestore(params);
        int restoredCount = 0;

        for (BlockLogEntry entry : entries) {
            ServerLevel level = findLevel(server, entry.world);
            if (level == null) {
                continue;
            }

            BlockPos pos = new BlockPos(entry.x, entry.y, entry.z);
            try {
                if (entry.action == BlockLogEntry.ACTION_PLACE) {
                    BlockState state = resolveState(entry.blockType);
                    if (state != null) {
                        level.m_7731_(pos, state, Block.f_152402_);
                        PrismProtect.getDatabase().setBlockRolledBack(entry.id, false);
                        restoredCount++;
                    }
                    continue;
                }

                if (entry.action == BlockLogEntry.ACTION_BREAK
                        || entry.action == BlockLogEntry.ACTION_EXPLODE
                        || entry.action == BlockLogEntry.ACTION_BURN) {
                    level.m_7731_(pos, Blocks.f_50016_.m_49966_(), Block.f_152402_);
                    PrismProtect.getDatabase().setBlockRolledBack(entry.id, false);
                    restoredCount++;
                }
            } catch (Exception ex) {
                PrismProtect.LOGGER.warn("Restore error at {}: {}", pos, ex.getMessage());
            }
        }

        return restoredCount;
    }

    public static int rollbackEntities(MinecraftServer server, LookupParams params) {
        List<EntityLogEntry> entries = PrismProtect.getDatabase().getEntitiesForRollback(params);
        int restoredCount = 0;

        for (EntityLogEntry entry : entries) {
            if (entry.action != EntityLogEntry.ACTION_KILL) {
                continue;
            }

            ServerLevel level = findLevel(server, entry.world);
            if (level == null) {
                continue;
            }

            try {
                ResourceLocation entityId = new ResourceLocation(entry.entityType);
                Optional<EntityType<?>> type = BuiltInRegistries.f_256780_.m_6612_(entityId);
                if (type.isEmpty()) {
                    continue;
                }

                Entity entity = type.get().m_20615_(level);
                if (entity == null) {
                    continue;
                }

                entity.m_6034_(entry.x, entry.y, entry.z);

                if (entry.entityData != null && !entry.entityData.isBlank()) {
                    try {
                        CompoundTag tag = TagParser.m_129359_(entry.entityData);
                        entity.m_20258_(tag);
                        entity.m_6034_(entry.x, entry.y, entry.z);
                    } catch (Exception nbtEx) {
                        PrismProtect.LOGGER.warn("Entity NBT restore failed: {}", nbtEx.getMessage());
                    }
                }

                level.m_7967_(entity);
                PrismProtect.getDatabase().setEntityRolledBack(entry.id, true);
                restoredCount++;
            } catch (Exception ex) {
                PrismProtect.LOGGER.warn("Entity rollback error: {}", ex.getMessage());
            }
        }

        return restoredCount;
    }

    public static int rollbackContainers(MinecraftServer server, LookupParams params) {
        List<ContainerLogEntry> entries = PrismProtect.getDatabase().getContainerForRollback(params);
        int restoredCount = 0;

        for (ContainerLogEntry entry : entries) {
            ServerLevel level = findLevel(server, entry.world);
            if (level == null) {
                continue;
            }

            BlockPos pos = new BlockPos(entry.x, entry.y, entry.z);
            ItemStack stack = buildStack(entry);
            if (stack.m_41619_()) {
                continue;
            }

            try {
                if (entry.action == ContainerLogEntry.ACTION_REMOVE) {
                    if (PrismProtect.getContainerAccess().addItem(level, pos, stack)) {
                        PrismProtect.getDatabase().setContainerRolledBack(entry.id, true);
                        restoredCount++;
                    }
                    continue;
                }

                if (entry.action == ContainerLogEntry.ACTION_ADD) {
                    if (PrismProtect.getContainerAccess().removeItem(level, pos, stack)) {
                        PrismProtect.getDatabase().setContainerRolledBack(entry.id, true);
                        restoredCount++;
                    }
                }
            } catch (Exception ex) {
                PrismProtect.LOGGER.warn("Container rollback error at {}: {}", pos, ex.getMessage());
            }
        }

        return restoredCount;
    }

    public static int restoreContainers(MinecraftServer server, LookupParams params) {
        List<ContainerLogEntry> entries = PrismProtect.getDatabase().getContainerForRestore(params);
        int restoredCount = 0;

        for (ContainerLogEntry entry : entries) {
            ServerLevel level = findLevel(server, entry.world);
            if (level == null) {
                continue;
            }

            BlockPos pos = new BlockPos(entry.x, entry.y, entry.z);
            ItemStack stack = buildStack(entry);
            if (stack.m_41619_()) {
                continue;
            }

            try {
                if (entry.action == ContainerLogEntry.ACTION_REMOVE) {
                    if (PrismProtect.getContainerAccess().removeItem(level, pos, stack)) {
                        PrismProtect.getDatabase().setContainerRolledBack(entry.id, false);
                        restoredCount++;
                    }
                    continue;
                }

                if (entry.action == ContainerLogEntry.ACTION_ADD) {
                    if (PrismProtect.getContainerAccess().addItem(level, pos, stack)) {
                        PrismProtect.getDatabase().setContainerRolledBack(entry.id, false);
                        restoredCount++;
                    }
                }
            } catch (Exception ex) {
                PrismProtect.LOGGER.warn("Container restore error at {}: {}", pos, ex.getMessage());
            }
        }

        return restoredCount;
    }

    private static ItemStack buildStack(ContainerLogEntry entry) {
        try {
            Item item = BuiltInRegistries.f_257033_.m_7745_(new ResourceLocation(entry.itemType));
            if (item == Items.f_41852_) {
                return ItemStack.f_41583_;
            }

            ItemStack stack = new ItemStack(item, entry.amount);
            if (entry.itemData != null && !entry.itemData.isBlank()) {
                stack.m_41751_(TagParser.m_129359_(entry.itemData));
            }
            return stack;
        } catch (Exception ex) {
            PrismProtect.LOGGER.warn("Failed to build ItemStack for {}: {}", entry.itemType, ex.getMessage());
            return ItemStack.f_41583_;
        }
    }

    private static BlockState resolveState(String id) {
        try {
            return BuiltInRegistries.f_256975_.m_7745_(new ResourceLocation(id)).m_49966_();
        } catch (Exception ex) {
            PrismProtect.LOGGER.warn("Unknown block: {}", id);
            return null;
        }
    }

    private static void restoreBlockEntity(ServerLevel level, BlockPos pos, String nbt) {
        try {
            BlockEntity blockEntity = level.m_7702_(pos);
            if (blockEntity != null && nbt.startsWith("{")) {
                blockEntity.m_142466_(TagParser.m_129359_(nbt));
                blockEntity.m_6596_();
            }
        } catch (Exception ex) {
            PrismProtect.LOGGER.warn("BlockEntity restore failed at {}: {}", pos, ex.getMessage());
        }
    }

    private static ServerLevel findLevel(MinecraftServer server, String worldName) {
        for (ServerLevel level : server.m_129785_()) {
            String location = level.m_46472_().m_135782_().toString();
            if (location.equals(worldName) || location.replace("minecraft:", "").equals(worldName)) {
                return level;
            }
        }
        return null;
    }
}
