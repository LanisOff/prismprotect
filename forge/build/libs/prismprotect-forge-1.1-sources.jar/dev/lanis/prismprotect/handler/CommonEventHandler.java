package dev.lanis.prismprotect.handler;

import dev.architectury.event.EventResult;
import dev.architectury.event.events.common.BlockEvent;
import dev.architectury.event.events.common.EntityEvent;
import dev.architectury.event.events.common.ExplosionEvent;
import dev.architectury.event.events.common.InteractionEvent;
import dev.architectury.event.events.common.PlayerEvent;
import dev.architectury.utils.value.IntValue;
import dev.lanis.prismprotect.PrismProtect;
import dev.lanis.prismprotect.database.BlockLogEntry;
import dev.lanis.prismprotect.database.EntityLogEntry;
import dev.lanis.prismprotect.database.LookupParams;
import dev.lanis.prismprotect.util.MessageUtil;
import dev.lanis.prismprotect.util.TimeUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public final class CommonEventHandler {

    private static final AtomicBoolean REGISTERED = new AtomicBoolean(false);

    private CommonEventHandler() {
    }

    public static void register() {
        if (!REGISTERED.compareAndSet(false, true)) {
            return;
        }

        BlockEvent.BREAK.register(CommonEventHandler::onBreak);
        BlockEvent.PLACE.register(CommonEventHandler::onPlace);
        ExplosionEvent.DETONATE.register(CommonEventHandler::onExplosion);
        EntityEvent.LIVING_DEATH.register(CommonEventHandler::onEntityDeath);
        InteractionEvent.RIGHT_CLICK_BLOCK.register(CommonEventHandler::onRightClickBlock);
        PlayerEvent.OPEN_MENU.register(CommonEventHandler::onContainerOpen);
        PlayerEvent.CLOSE_MENU.register(CommonEventHandler::onContainerClose);
        PlayerEvent.PLAYER_QUIT.register(CommonEventHandler::onPlayerLogout);
    }

    private static EventResult onBreak(
            Level level,
            BlockPos pos,
            BlockState state,
            ServerPlayer player,
            IntValue xp
    ) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return EventResult.pass();
        }

        if (InspectManager.isInspecting(player.m_20148_())) {
            showInspect(player, serverLevel, pos, blockId(state));
            return EventResult.interruptFalse();
        }

        PrismProtect.getDatabase().logBlock(new BlockLogEntry(
                now(),
                player.m_36316_().getName(),
                worldName(serverLevel),
                pos.m_123341_(),
                pos.m_123342_(),
                pos.m_123343_(),
                blockId(state),
                beData(serverLevel, pos),
                BlockLogEntry.ACTION_BREAK
        ));

        return EventResult.pass();
    }

    private static EventResult onPlace(Level level, BlockPos pos, BlockState state, Entity placer) {
        if (!(level instanceof ServerLevel serverLevel) || !(placer instanceof ServerPlayer player)) {
            return EventResult.pass();
        }

        PrismProtect.getDatabase().logBlock(new BlockLogEntry(
                now(),
                player.m_36316_().getName(),
                worldName(serverLevel),
                pos.m_123341_(),
                pos.m_123342_(),
                pos.m_123343_(),
                blockId(state),
                null,
                BlockLogEntry.ACTION_PLACE
        ));

        return EventResult.pass();
    }

    private static void onExplosion(Level level, Explosion explosion, List<Entity> affectedEntities) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }

        String world = worldName(serverLevel);
        String source = resolveExplosionSource(explosion);
        long eventTime = now();

        for (BlockPos pos : explosion.m_46081_()) {
            BlockState state = serverLevel.m_8055_(pos);
            if (state.m_60795_()) {
                continue;
            }

            PrismProtect.getDatabase().logBlock(new BlockLogEntry(
                    eventTime,
                    source,
                    world,
                    pos.m_123341_(),
                    pos.m_123342_(),
                    pos.m_123343_(),
                    blockId(state),
                    beData(serverLevel, pos),
                    BlockLogEntry.ACTION_EXPLODE
            ));
        }

        BlockChangeContext.EXPLOSION_HANDLED.set(true);
    }

    private static EventResult onEntityDeath(LivingEntity target, DamageSource source) {
        if (target instanceof Player || !(target.m_9236_() instanceof ServerLevel serverLevel)) {
            return EventResult.pass();
        }

        ServerPlayer killer = source.m_7639_() instanceof ServerPlayer serverPlayer ? serverPlayer : null;

        String entityType = BuiltInRegistries.f_256780_.m_7981_(target.m_6095_()).toString();
        CompoundTag serialized = new CompoundTag();
        target.m_20223_(serialized);

        PrismProtect.getDatabase().logEntity(new EntityLogEntry(
                now(),
                killer != null ? killer.m_36316_().getName() : "#environment",
                worldName(serverLevel),
                target.m_20185_(),
                target.m_20186_(),
                target.m_20189_(),
                entityType,
                serialized.toString(),
                EntityLogEntry.ACTION_KILL
        ));

        return EventResult.pass();
    }

    private static EventResult onRightClickBlock(Player player, InteractionHand hand, BlockPos pos, Direction face) {
        if (!(player instanceof ServerPlayer serverPlayer) || !(player.m_9236_() instanceof ServerLevel serverLevel)) {
            return EventResult.pass();
        }

        ContainerTracker.storeInteract(serverPlayer.m_20148_(), pos, worldName(serverLevel));

        if (InspectManager.isInspecting(serverPlayer.m_20148_())) {
            BlockState state = serverLevel.m_8055_(pos);
            showInspect(serverPlayer, serverLevel, pos, blockId(state));
            return EventResult.interruptFalse();
        }

        return EventResult.pass();
    }

    private static void onContainerOpen(Player player, AbstractContainerMenu menu) {
        if (player instanceof ServerPlayer serverPlayer) {
            ContainerTracker.onOpen(serverPlayer.m_20148_(), menu);
        }
    }

    private static void onContainerClose(Player player, AbstractContainerMenu menu) {
        if (player instanceof ServerPlayer serverPlayer) {
            ContainerTracker.onClose(serverPlayer.m_20148_(), menu, serverPlayer.m_36316_().getName());
        }
    }

    private static void onPlayerLogout(ServerPlayer player) {
        ContainerTracker.clear(player.m_20148_());
    }

    private static void showInspect(ServerPlayer player, Level level, BlockPos pos, String blockType) {
        LookupParams params = new LookupParams();
        params.world = worldName(level);
        params.minX = pos.m_123341_();
        params.maxX = pos.m_123341_();
        params.minY = pos.m_123342_();
        params.maxY = pos.m_123342_();
        params.minZ = pos.m_123343_();
        params.maxZ = pos.m_123343_();
        params.limit = 10;

        List<BlockLogEntry> entries = PrismProtect.getDatabase().lookupBlocks(params);

        player.m_213846_(MessageUtil.header("Block Info"));
        player.m_213846_(Component.m_237113_(
                "§7Block: §e" + blockType + " §7(" + pos.m_123341_() + "," + pos.m_123342_() + "," + pos.m_123343_() + ")"
        ));

        if (entries.isEmpty()) {
            player.m_213846_(MessageUtil.warn("No history found for this block."));
            return;
        }

        for (BlockLogEntry entry : entries) {
            player.m_213846_(Component.m_237113_(String.format(
                    "§7%s §f%s §7%s §e%s%s",
                    TimeUtil.elapsed(entry.time),
                    entry.player,
                    entry.actionName(),
                    entry.blockType,
                    entry.rolledBack ? " §8[rb]" : ""
            )));
        }
    }

    public static String blockId(BlockState state) {
        return BuiltInRegistries.f_256975_.m_7981_(state.m_60734_()).toString();
    }

    private static String resolveExplosionSource(Explosion explosion) {
        DamageSource damageSource = explosion.m_46077_();
        if (damageSource == null) {
            return "#explosion";
        }

        Entity indirect = damageSource.m_7639_();
        if (indirect instanceof ServerPlayer player) {
            return player.m_36316_().getName();
        }

        Entity direct = damageSource.m_7640_();
        if (direct != null) {
            return "#" + BuiltInRegistries.f_256780_.m_7981_(direct.m_6095_()).m_135815_();
        }

        return "#explosion";
    }

    private static String worldName(Level level) {
        return level.m_46472_().m_135782_().toString();
    }

    private static String beData(Level level, BlockPos pos) {
        BlockEntity blockEntity = level.m_7702_(pos);
        if (blockEntity == null) {
            return null;
        }

        CompoundTag tag = blockEntity.m_187482_();
        return tag.m_128456_() ? null : tag.toString();
    }

    private static long now() {
        return System.currentTimeMillis();
    }
}
