package dev.lanis.prismprotect.handler;

import dev.lanis.prismprotect.PrismProtect;
import dev.lanis.prismprotect.database.ContainerLogEntry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ContainerTracker {

    private static final Map<UUID, BlockInfo> LAST_INTERACTED_BLOCK = new ConcurrentHashMap<>();
    private static final Map<UUID, Snapshot> SNAPSHOTS = new ConcurrentHashMap<>();

    private ContainerTracker() {
    }

    record BlockInfo(BlockPos pos, String world) {
    }

    record Snapshot(BlockPos pos, String world, Map<String, SlotCount> counts) {
    }

    record SlotCount(String itemType, String itemData, int count) {
    }

    public static void storeInteract(UUID playerId, BlockPos pos, String world) {
        LAST_INTERACTED_BLOCK.put(playerId, new BlockInfo(pos, world));
    }

    public static void onOpen(UUID playerId, AbstractContainerMenu menu) {
        BlockInfo blockInfo = LAST_INTERACTED_BLOCK.get(playerId);
        if (blockInfo == null) {
            return;
        }

        SNAPSHOTS.put(playerId, new Snapshot(blockInfo.pos, blockInfo.world, aggregate(menu)));
    }

    public static void onClose(UUID playerId, AbstractContainerMenu menu, String playerName) {
        Snapshot snapshot = SNAPSHOTS.remove(playerId);
        if (snapshot == null) {
            return;
        }

        Map<String, SlotCount> before = snapshot.counts;
        Map<String, SlotCount> after = aggregate(menu);
        long eventTime = System.currentTimeMillis();

        for (Map.Entry<String, SlotCount> entry : before.entrySet()) {
            SlotCount beforeCount = entry.getValue();
            int previous = beforeCount.count;
            int current = after.getOrDefault(entry.getKey(), new SlotCount(beforeCount.itemType, beforeCount.itemData, 0)).count;

            int diff = previous - current;
            if (diff > 0) {
                PrismProtect.getDatabase().logContainer(new ContainerLogEntry(
                        eventTime,
                        playerName,
                        snapshot.world,
                        snapshot.pos.m_123341_(),
                        snapshot.pos.m_123342_(),
                        snapshot.pos.m_123343_(),
                        beforeCount.itemType,
                        diff,
                        beforeCount.itemData,
                        ContainerLogEntry.ACTION_REMOVE
                ));
            }
        }

        for (Map.Entry<String, SlotCount> entry : after.entrySet()) {
            SlotCount afterCount = entry.getValue();
            int current = afterCount.count;
            int previous = before.getOrDefault(entry.getKey(), new SlotCount(afterCount.itemType, afterCount.itemData, 0)).count;

            int diff = current - previous;
            if (diff > 0) {
                PrismProtect.getDatabase().logContainer(new ContainerLogEntry(
                        eventTime,
                        playerName,
                        snapshot.world,
                        snapshot.pos.m_123341_(),
                        snapshot.pos.m_123342_(),
                        snapshot.pos.m_123343_(),
                        afterCount.itemType,
                        diff,
                        afterCount.itemData,
                        ContainerLogEntry.ACTION_ADD
                ));
            }
        }
    }

    public static void clear(UUID playerId) {
        LAST_INTERACTED_BLOCK.remove(playerId);
        SNAPSHOTS.remove(playerId);
    }

    private static Map<String, SlotCount> aggregate(AbstractContainerMenu menu) {
        Map<String, SlotCount> counts = new LinkedHashMap<>();

        for (Slot slot : menu.f_38839_) {
            if (slot.f_40218_ instanceof Inventory) {
                continue;
            }

            ItemStack stack = slot.m_7993_();
            if (stack.m_41619_()) {
                continue;
            }

            String key = itemKey(stack);
            String itemType = BuiltInRegistries.f_257033_.m_7981_(stack.m_41720_()).toString();
            String itemData = nbtWithoutCount(stack);

            counts.merge(
                    key,
                    new SlotCount(itemType, itemData, stack.m_41613_()),
                    (previous, next) -> new SlotCount(previous.itemType, previous.itemData, previous.count + next.count)
            );
        }

        return counts;
    }

    private static String itemKey(ItemStack stack) {
        String type = BuiltInRegistries.f_257033_.m_7981_(stack.m_41720_()).toString();
        CompoundTag tag = stack.m_41783_();
        return type + (tag != null ? "|" + tag : "");
    }

    private static String nbtWithoutCount(ItemStack stack) {
        if (!stack.m_41782_()) {
            return null;
        }

        CompoundTag copy = stack.m_41783_().m_6426_();
        copy.m_128473_("Count");
        return copy.m_128456_() ? null : copy.toString();
    }
}
