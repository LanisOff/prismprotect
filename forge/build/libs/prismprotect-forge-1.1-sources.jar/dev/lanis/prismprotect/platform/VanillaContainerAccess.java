package dev.lanis.prismprotect.platform;

import dev.lanis.prismprotect.PrismProtect;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

public class VanillaContainerAccess implements ContainerAccess {

    @Override
    public boolean addItem(ServerLevel level, BlockPos pos, ItemStack stack) {
        BlockEntity be = level.m_7702_(pos);
        if (!(be instanceof Container container)) {
            PrismProtect.LOGGER.warn("Block at {} has no vanilla inventory", pos);
            return false;
        }

        ItemStack remaining = stack.m_41777_();
        for (int slot = 0; slot < container.m_6643_() && !remaining.m_41619_(); slot++) {
            ItemStack existing = container.m_8020_(slot);
            if (existing.m_41619_()) {
                container.m_6836_(slot, remaining.m_41620_(remaining.m_41613_()));
            } else if (ItemStack.m_150942_(existing, remaining)) {
                int space = Math.min(remaining.m_41613_(), existing.m_41741_() - existing.m_41613_());
                if (space > 0) {
                    existing.m_41769_(space);
                    remaining.m_41774_(space);
                }
            }
        }

        be.m_6596_();
        return true;
    }

    @Override
    public boolean removeItem(ServerLevel level, BlockPos pos, ItemStack stack) {
        BlockEntity be = level.m_7702_(pos);
        if (!(be instanceof Container container)) {
            PrismProtect.LOGGER.warn("Block at {} has no vanilla inventory", pos);
            return false;
        }

        int toRemove = stack.m_41613_();
        for (int slot = 0; slot < container.m_6643_() && toRemove > 0; slot++) {
            ItemStack slotStack = container.m_8020_(slot);
            if (!slotStack.m_41619_() && ItemStack.m_150942_(slotStack, stack)) {
                int take = Math.min(slotStack.m_41613_(), toRemove);
                slotStack.m_41774_(take);
                if (slotStack.m_41619_()) {
                    container.m_6836_(slot, ItemStack.f_41583_);
                }
                toRemove -= take;
            }
        }

        be.m_6596_();
        return true;
    }
}
