package dev.lanis.prismprotect.platform.forge;

import dev.lanis.prismprotect.PrismProtect;
import dev.lanis.prismprotect.platform.VanillaContainerAccess;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.items.IItemHandlerModifiable;

public class ForgeContainerAccess extends VanillaContainerAccess {

    @Override
    public boolean addItem(ServerLevel level, BlockPos pos, ItemStack stack) {
        BlockEntity be = level.m_7702_(pos);
        if (be == null) {
            PrismProtect.LOGGER.warn("No block entity at {} for container rollback", pos);
            return false;
        }

        var capOpt = be.getCapability(ForgeCapabilities.ITEM_HANDLER).resolve();
        if (capOpt.isPresent() && capOpt.get() instanceof IItemHandlerModifiable handler) {
            ItemStack remaining = stack.m_41777_();
            for (int slot = 0; slot < handler.getSlots() && !remaining.m_41619_(); slot++) {
                remaining = handler.insertItem(slot, remaining, false);
            }
            if (!remaining.m_41619_()) {
                PrismProtect.LOGGER.warn(
                        "Could not fully add {} x{} to container at {} ({} remaining)",
                        stack.m_41720_(), stack.m_41613_(), pos, remaining.m_41613_());
            }
            be.m_6596_();
            return true;
        }

        return super.addItem(level, pos, stack);
    }

    @Override
    public boolean removeItem(ServerLevel level, BlockPos pos, ItemStack stack) {
        BlockEntity be = level.m_7702_(pos);
        if (be == null) {
            PrismProtect.LOGGER.warn("No block entity at {} for container restore", pos);
            return false;
        }

        var capOpt = be.getCapability(ForgeCapabilities.ITEM_HANDLER).resolve();
        if (capOpt.isPresent() && capOpt.get() instanceof IItemHandlerModifiable handler) {
            int toRemove = stack.m_41613_();
            for (int slot = 0; slot < handler.getSlots() && toRemove > 0; slot++) {
                ItemStack slotStack = handler.getStackInSlot(slot);
                if (!slotStack.m_41619_() && ItemStack.m_150942_(slotStack, stack)) {
                    int take = Math.min(slotStack.m_41613_(), toRemove);
                    handler.extractItem(slot, take, false);
                    toRemove -= take;
                }
            }
            be.m_6596_();
            return true;
        }

        return super.removeItem(level, pos, stack);
    }
}
