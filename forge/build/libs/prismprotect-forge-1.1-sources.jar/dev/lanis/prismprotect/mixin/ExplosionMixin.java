package dev.lanis.prismprotect.mixin;

import dev.lanis.prismprotect.PrismProtect;
import dev.lanis.prismprotect.database.BlockLogEntry;
import dev.lanis.prismprotect.handler.BlockChangeContext;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Explosion.class)
public abstract class ExplosionMixin {

    @Final @Shadow private Level level;

    @Inject(method = "finalizeExplosion", at = @At("HEAD"))
    private void prismprotect$maybeLogExplosion(boolean causeFire, CallbackInfo ci) {
        if (BlockChangeContext.EXPLOSION_HANDLED.get()) return;
        if (!(level instanceof ServerLevel sl)) return;

        Explosion explosion = (Explosion) (Object) this;
        String source = resolveSource(explosion.m_46077_());
        String world = sl.m_46472_().m_135782_().toString();
        long now = System.currentTimeMillis();

        for (BlockPos pos : explosion.m_46081_()) {
            BlockState state = sl.m_8055_(pos);
            if (state.m_60795_()) continue;

            String beData = null;
            BlockEntity be = sl.m_7702_(pos);
            if (be != null) {
                CompoundTag tag = be.m_187482_();
                if (!tag.m_128456_()) beData = tag.toString();
            }

            PrismProtect.getDatabase().logBlock(new BlockLogEntry(
                    now, source, world,
                    pos.m_123341_(), pos.m_123342_(), pos.m_123343_(),
                    BuiltInRegistries.f_256975_.m_7981_(state.m_60734_()).toString(),
                    beData, BlockLogEntry.ACTION_EXPLODE
            ));
        }
    }

    @Inject(method = "finalizeExplosion", at = @At("RETURN"))
    private void prismprotect$clearFlag(boolean causeFire, CallbackInfo ci) {
        BlockChangeContext.EXPLOSION_HANDLED.set(false);
    }

    private static String resolveSource(DamageSource ds) {
        Entity indirect = ds.m_7639_();
        if (indirect instanceof ServerPlayer sp)
            return sp.m_36316_().getName();
        Entity direct = ds.m_7640_();
        if (direct != null)
            return "#" + BuiltInRegistries.f_256780_.m_7981_(direct.m_6095_()).m_135815_();
        return "#explosion";
    }
}
